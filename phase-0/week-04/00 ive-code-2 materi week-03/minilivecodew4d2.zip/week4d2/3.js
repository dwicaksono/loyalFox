
/**
 * 
 *  Belanja
 * 
 *  Function ini akan membalikkan output yang berupa daftar belanjaan
 *  yang dapat di beli dengan uang yang ada. 
 *  Barang yang menjadi prioritas di beli yaitu dari yang paling mahal dahulu
 * 
 *  contoh: 
 *  1. Belanjaan: [[20000, "bola"], [15000, "sepatu"], [50000, "susu"]] 
 *  2. Uang: 65000
 * 
 *  Maka barang yang dapat di beli adalah 
 *  Output: ['susu', 'sepatu']
 * 
 *  RULES:
 *  - Dilarang menggunakan OBJEK
 *  - Dilarang menggunakan .filter, .map, Math.max(), .sort, Math.min()
 */

function belanja (belanjaan, uang) {
  console.log(belanjaan, uang)
}

console.log(belanja([[150000, "Batik Jawa"],[250000, "Wayang"],[30000, "Gantungan Kunci"]], 410000))
// ["Wayang", "Batik Jawa"]
console.log(belanja([[70000, "KFC"], [14000, "Bakso"], [20000, "Ayam Penyet"]], 85000))
// ["KFC", "Bakso"]
console.log(belanja([[200000, "Avanza"], [500000, "Innova"], [450000, "Terios"]], 150000))
// Tidak ada yang bisa dibeli
console.log(belanja([[45000, "Starbucks"], [23000, "Jus Alpukat"], [10000, "Marimas"]], 100000))
//["Starbucks", "Jus Alpukat", "Marimas"]